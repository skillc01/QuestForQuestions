# TODO List

## bug fixes
* Submitter field on questions and answers (adding)
* redirection from creation question/answer to go to correct place

## Features
* Login page
* Login via oauth
* From another device - login in, go to a question room and view that
* make it pretty
