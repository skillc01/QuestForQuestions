from django.contrib import admin
from guardian.admin import GuardedModelAdmin

from .models import Room, Question, Answer


class RoomAdmin(GuardedModelAdmin):
    pass

# Register models
class QuestionAdmin(GuardedModelAdmin):
    list_display = ["__str__", "room", "votes"]
    list_filter = ["category", "room"]
    search_fields = ["text"]

admin.site.register(Question, QuestionAdmin)
admin.site.register(Room, RoomAdmin)
admin.site.register(Answer)
