from django.apps import AppConfig


class HackessexConfig(AppConfig):
    name = 'hackessex'
