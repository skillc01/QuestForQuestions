from .models import Room, Question
from .serializers import RoomSerializer, QuestionSerializer
from .permissions import IsOwnerOrReadOnly

from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import detail_route, list_route

from django_filters import rest_framework as filters

class RoomViewSet(viewsets.ModelViewSet):
    serializer_class = RoomSerializer
    queryset = Room.objects.all()

    def perform_create(self, serializer):
        serializer.save(submitter=self.request.user)

class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.filter(hidden=False)
    serializer_class = QuestionSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    permission_classes = (IsOwnerOrReadOnly,)
    filter_fields = ['room',]
    ordering_fields = ('room', 'votes')

    @detail_route(methods=['post'])
    def vote(self, request, pk=None):
        question = self.get_object()
        if 'vote' not in request.data or request.data['vote'] not in ['up', 'down']:
            return Response(
                {"error": "only use up or down as vote keywords"},
                status=status.HTTP_400_BAD_REQUEST
            )

        if request.data['vote'] == "up" :
            question.votes += 1
        elif request.data['vote'] == "down":
            question.votes -= 1
        question.save()
        return Response({"status": "vote processed"})

    def perform_create(self, serializer):
        serializer.save(submitter=self.request.user)
