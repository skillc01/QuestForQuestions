from .models import Room, Question, Answer
from rest_framework import serializers

class RoomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Room
        fields = '__all__'

class QuestionSerializer(serializers.ModelSerializer):
    hidden = serializers.ReadOnlyField()
    votes = serializers.ReadOnlyField()
    class Meta:
        model = Question
        exclude = ('submitter',)

class AnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answer
        fields = '__all__'
